//
//  CoreExtension.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import Foundation


extension JobRole {
    var interviewSlotsArray: [InterviewSlot] {
        
        let interviewSlotsSet = self.interviewSlots as? Set<InterviewSlot>
        let interviewSlotsArray = interviewSlotsSet?.sorted { $0.date ?? Date() < $1.date ?? Date() } ?? []
        return interviewSlotsArray
    }
}

