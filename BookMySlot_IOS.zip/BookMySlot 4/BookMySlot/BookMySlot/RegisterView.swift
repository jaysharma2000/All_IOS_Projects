//
//  RegisterView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//
import SwiftUI

struct RegisterView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) var dismiss
    
    @State private var username = ""
    @State private var password = ""
    @State private var isRegistered = false
    @State private var error = false
    
    var body: some View {
        VStack {
            Text("Register")
                .font(.largeTitle)
                .foregroundColor(.white)
                .padding()
                .accessibilityIdentifier("registerText")
            
            TextField("Enter username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .foregroundColor(.white)
                .background(Color.gray.opacity(0.2))
                .accessibilityIdentifier("userNameReg")
            
            SecureField("Enter password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .foregroundColor(.white)
                .background(Color.gray.opacity(0.2))
                .accessibilityIdentifier("passwordReg")
            
            Button(action: registerAdmin) {
                Text("Register")
                    .foregroundColor(.white)
            }
            .buttonStyle(.borderedProminent)
            .padding()
            .accessibilityIdentifier("registerButton")
            
            if isRegistered {
                Text("Registration Successful")
                    .foregroundColor(.green)
                    .padding()
            }
        }
        .background(Color.black)
        .preferredColorScheme(.dark)
        .navigationBarHidden(true)
    }
    
    func registerAdmin() {
        let newAdmin = Admin(context: viewContext)
        
        newAdmin.username = username
        newAdmin.password = password
        
        do {
            try viewContext.save()
            isRegistered = true
        } catch {
            print("Error registering user: \(error)")
        }
        
        dismiss()
    }
}
