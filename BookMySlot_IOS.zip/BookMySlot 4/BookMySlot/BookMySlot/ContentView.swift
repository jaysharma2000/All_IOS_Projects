//
//  ContentView.swift
//  BookMySlot
//
//  Created by admin on 14/02/25.
//

import SwiftUI

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: JobRole.entity(),
        sortDescriptors: []
    ) private var jobRoles: FetchedResults<JobRole>
    
    @State private var isShowingAddJobRole = false
    @State private var isShowingEditJobRole = false
    @State private var selectedJobRole: JobRole?
    
    var body: some View {
        NavigationView {
            List {
                ForEach(jobRoles) { jobRole in
                    HStack{
                        NavigationLink(destination: InterviewSlotsView(jobRole: jobRole)) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(jobRole.title ?? "Unnamed jobRole")
                                    .padding(.top, 10)
                                    .padding(.bottom, 5)
                                    .font(.system(size: 20, weight: .semibold))
                                    .accessibilityIdentifier("jobTitle")
                                
                               
                                Text(jobRole.techStack ?? "Unnamed techStack")
                                    .padding(.top, 10)
                                    .padding(.bottom, 5)
                                    .font(.system(size: 20, weight: .semibold))                            }
                        }
                        Spacer()
                        
                        Button(action: {
                            selectedJobRole = jobRole
                            isShowingEditJobRole = true
                        }) {
                            Image(systemName: "pencil")
                                .foregroundColor(.blue)
                                .font(.system(size: 30))
                        }
                        .buttonStyle(BorderlessButtonStyle())
                    }
                }
                .onDelete(perform: deleteJobRole)
            }
            .navigationBarTitle("Job Roles", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Job Roles")
                        .font(.title.bold())
                        .padding(.vertical, 5)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { isShowingAddJobRole = true }) {
                        Image(systemName: "plus")
                    }.accessibilityIdentifier("addJobTitleButton")
                }
            }
            .sheet(isPresented: $isShowingAddJobRole) {
                AddJobRoleView()
            }
            .sheet(item: $selectedJobRole) { jobRole in
                EditJobRoleView(jobRole : jobRole)
            }
        }
    }
    
    private func deleteJobRole(at offsets: IndexSet) {
        for index in offsets {
            let jobRole = jobRoles[index]
            viewContext.delete(jobRole)
        }
        
        DispatchQueue.main.async {
            do {
                try viewContext.save()
            } catch {
                print("Error deleting jobRole: \(error.localizedDescription)")
            }
        }
    }}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
