//
//  AddInterviewSlotsView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import SwiftUI

struct AddInterviewSlotsView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode
    
    
    @State private var interviewerName: String = ""
    @State private var designation: String = ""
    @State private var time: String = ""
    @State private var isBooked: Bool  = false
    @State private var date: Date  = Date()
    @State private var bookingStatus: String = "Available"
    @ObservedObject var jobRole: JobRole
  
    var body: some View {
        NavigationView {
            Form {
                Section(
                    header: Text("Interview Slots Details")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .center)
                ) {
                    TextField("Enter interviewer name", text: $interviewerName)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Enter interviewer designation", text: $designation)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Enter interviewer time slot", text: $time)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    DatePicker("Select Date", selection: $date, displayedComponents: .date)
                    Picker("Booking Status", selection: $bookingStatus) {
                                    Text("Available").tag("Available")
                                    Text("Booked").tag("Booked")
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .font(.system(size: 18))
                                .padding(.vertical, 10)
                    
                }
                
                Section {
                    HStack {
                        Spacer()
                        
                        Button("Save") {
                            saveInterviewSlot()
                        }
                        .disabled(interviewerName.isEmpty)
                        
                        Spacer()
                    }
                }
            }
            
            .navigationBarTitle("Add New Interview Slot", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Add New Interview Slot")
                        .font(.system(size: 22, weight: .bold))
                        .padding(.top, 10)
                        .padding(.bottom, 5)
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
    
    
    private func saveInterviewSlot() {
        
        let newInterviewSlot = InterviewSlot(context: viewContext)
        newInterviewSlot.id = UUID()
        newInterviewSlot.interviewerName = interviewerName
        newInterviewSlot.designation = designation
        newInterviewSlot.date = date
        newInterviewSlot.time = time
        newInterviewSlot.isBooked = isBooked
        newInterviewSlot.jobRole = jobRole
        
        
        DispatchQueue.main.async {
            do {
                try viewContext.save()
                presentationMode.wrappedValue.dismiss()
            } catch {
                print("Failed to save interviewSlot: \(error.localizedDescription)")
            }
        }
    }}



