//
//  EditJobRoleView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import SwiftUI

struct EditJobRoleView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode
    
    @State private var title: String = ""
    @State private var tectStack : String = ""
    
    @ObservedObject var jobRole: JobRole
    
    var body: some View {
        NavigationView {
            Form {
                Section (
                    header: Text("JobRole Details")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .center)
                ) {
                    TextField("Enter jobrole", text: $title)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Enter techStack", text: $tectStack)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                }
                
                Section {
                    HStack {
                        Spacer()
                        
                        Button("Update JobRole") {
                            updateJobRole()
                        }
                        .disabled(title.isEmpty)
                        
                        Spacer()
                    }
                }
            }
            .navigationBarTitle("Edit JobRole", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Edit JobRole")
                        .font(.system(size: 22, weight: .bold))
                        .padding(.top, 10)
                        .padding(.bottom, 5)
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                }
            )
            .onAppear{
                title = jobRole.title ?? ""
                tectStack = jobRole.techStack ?? ""
            }
        }
        
    }
    
    private func updateJobRole() {
        jobRole.title = title
        jobRole.techStack = tectStack
        
        DispatchQueue.main.async {
            do {
                try viewContext.save()
                presentationMode.wrappedValue.dismiss()
            } catch {
                print("Failed to update jobrole: \(error.localizedDescription)")
            }
        }
    }
}


