//
//  LoginView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import SwiftUI

struct LoginView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(entity: Admin.entity(), sortDescriptors: []) private var admin: FetchedResults<Admin>
    
    @State private var email = ""
    @State private var password = ""
    @State private var isAuthenticated = false
    @State private var error = false

    var body: some View {
        NavigationView {
            VStack {
                Text("Login")
                    .font(.largeTitle)
                    .foregroundColor(.white) 
                    .padding()
                
                TextField("Enter email", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.gray.opacity(0.2))
                    .accessibilityIdentifier("loginUsername")
                
                SecureField("Enter password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.gray.opacity(0.2))
                    .accessibilityIdentifier("loginPassword")
                
                Button(action: loginAdmin) {
                    Text("Login")
                        .foregroundColor(.white)
                }
                .accessibilityIdentifier("loginButton")
                .buttonStyle(.borderedProminent)
                .padding()
                
                if error {
                    Text("Invalid credentials, Try again")
                        .foregroundColor(.red)
                        .padding()
                }
                
                NavigationLink(destination: RegisterView()) {
                    Text("Register Here")
                        .foregroundColor(.white)
                }
                .padding()
                .accessibilityIdentifier("registerButton")
            }
            .background(Color.black)
            .fullScreenCover(isPresented: $isAuthenticated) {
                ContentView()
            }
            .navigationBarHidden(true)
        }
        .preferredColorScheme(.dark)
    }
    
    func loginAdmin() {
        if admin.contains(where: { $0.username == email && $0.password == password }) {
            isAuthenticated = true
        } else {
            error = true
        }
    }
}
