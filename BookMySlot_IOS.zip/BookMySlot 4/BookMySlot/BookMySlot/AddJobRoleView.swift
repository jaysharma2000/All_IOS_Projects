//
//  AddJobRoleView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import SwiftUI

struct AddJobRoleView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode
    
    @State private var title: String = ""
    @State private var tectStack : String = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(
                    header: Text("Add JobRole")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .center)
                ) {
                    TextField("Enter Jobrole Title", text: $title)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .accessibilityIdentifier("jobRoleTitle")
                    
                    TextField("Enter tech stack", text: $tectStack)
                        .font(.system(size: 18))
                        .padding(.vertical, 10)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .accessibilityIdentifier("jobRoleTechStack")
                }
                
                Section {
                    HStack {
                        Spacer()
                        
                        Button("Save") {
                            saveJobRole()
                        }
                        .disabled(title.isEmpty)
                        .accessibilityIdentifier("saveJobRoleBtn")
                        
                        Spacer()
                    }
                }
            }
            .navigationBarTitle("Add New JobRole", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Add New JobRole")
                        .font(.system(size: 22, weight: .bold))
                        .padding(.top, 10)
                        .padding(.bottom, 5)
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
        func saveJobRole() {
            guard !title.isEmpty else { return }
            
            let newJobRole = JobRole(context: viewContext)
            newJobRole.id = UUID()
            newJobRole.title = title
            newJobRole.techStack = tectStack
            
            DispatchQueue.main.async {
                do {
                    try viewContext.save()
                    presentationMode.wrappedValue.dismiss()
                } catch {
                    print("Failed to save jobrole: \(error.localizedDescription)")
                }
            }
        }
    }

        
