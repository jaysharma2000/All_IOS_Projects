//
//  InterviewSlotsView.swift
//  BookMySlot
//
//  Created by admin on 15/02/25.
//

import SwiftUI
import CoreData

struct InterviewSlotsView: View {

    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(entity: InterviewSlot.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \InterviewSlot.date, ascending: true)])
    private var slots: FetchedResults<InterviewSlot>
    
    @ObservedObject var jobRole: JobRole
    
    @State private var isShowingAddInterviewSlots = false
    @State private var isShowingEditInterviewSlots = false
    @State private var selectedInterviewSlot: InterviewSlot?
    @State private var showMessage: Bool = false
    
    var body: some View {
        VStack {
            List {
                ForEach(slots.filter{ $0.jobRole == jobRole }) { interviewSlot in
                    HStack {
                        VStack(alignment: .leading, spacing: 8) {
                            
                            Text("Interviewer Name: ").bold() + Text(interviewSlot.interviewerName ?? "Unnamed slot")
                                .font(.system(size: 18))
                               
                            Text("Designation: ").bold() + Text(interviewSlot.designation ?? "N/A")
                                .font(.subheadline)
                            
                            Text("Available Date: ").bold() + Text(interviewSlot.date ?? Date(), style: .date)
                            
                            Text("Available Slot: ").bold() + Text(interviewSlot.time ?? "N/A")
                                .font(.subheadline)
                            
                            HStack {
                                Text("Booking Status: ").bold()
                                Text(interviewSlot.isBooked ? "Booked" : "Available")
                                    .padding().foregroundColor(interviewSlot.isBooked ? .red : .green)
                            }
                            
                            HStack{
                                if !interviewSlot.isBooked {
                                    Button(action: {
                                        interviewSlot.isBooked = true
                                        interviewSlot.showMessage = true
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                            interviewSlot.showMessage = false
                                    }
                                }) {
                                    Text("Book Slot")
                                        .font(.system(size: 16))
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 12)
                                        .background(Color.green)
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                        .accessibilityIdentifier("bookSlot")
                                  }
                                    .frame(width: 120).padding(.leading, -10)                                } else {
                                    Button(action: {
                                        interviewSlot.isBooked = false
                                        interviewSlot.showMessage = false
                                    }) {
                                        Text("Cancel")
                                            .font(.system(size: 16))
                                            .padding(.vertical, 8)
                                            .padding(.horizontal, 12)
                                            .background(Color.red)
                                            .foregroundColor(.white)
                                            .cornerRadius(8)
                                    }.frame(width: 120).padding(.leading, -15)
                                }
                        
                                if interviewSlot.showMessage {
                                    Text("Slot booked successfully!")
                                        .foregroundColor(.green)
                                        .padding(.top, 10)
                            }
                        }
                    }
                  }
                }
                .onDelete(perform: deleteInterviewSlot)
            }
            .navigationBarTitle("Interview Slots", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Interview Slots")
                        .font(.title.bold())
                        .padding(.vertical, 5)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { isShowingAddInterviewSlots = true }) {
                        Image(systemName: "plus")
                    }.accessibilityIdentifier("addInterviewSlotBtn")
                }
            }
            .sheet(isPresented: $isShowingAddInterviewSlots) {
                AddInterviewSlotsView(jobRole: jobRole)
            }
        }.onAppear {
            print("Fetched InterviewSlots: \(jobRole.interviewSlotsArray.count)")
        }
    }
    
    private func deleteInterviewSlot(at offsets: IndexSet) {
        for index in offsets {
            let interviewSlot = jobRole.interviewSlotsArray[index]
            viewContext.delete(interviewSlot)
        }
        
        DispatchQueue.main.async {
            do {
                try viewContext.save()
            } catch {
                print("Failed to save context: \(error.localizedDescription)")
            }
        }
    }
}
