//
//  BookMySlotApp.swift
//  BookMySlot
//
//  Created by admin on 14/02/25.
//

import SwiftUI

@main
struct BookMySlotApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            LoginView().environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
