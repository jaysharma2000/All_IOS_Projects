//
//  BudgetTrackerApp.swift
//  BudgetTracker
//
//  Created by admin on 28/01/25.
//

import SwiftUI

@main
struct BudgetTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}
